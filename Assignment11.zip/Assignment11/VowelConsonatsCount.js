let str = prompt("Enter a string: ");
let vowels = "aeiouAEIOU";
let vowelCount = 0;
let consonantCount = 0;

for (let char of str) {
    if (vowels.includes(char)) {
        vowelCount++;
    } else if (char.match(/[a-zA-Z]/)) {
        consonantCount++;
    }
}

console.log("Vowels:", vowelCount);
console.log("Consonants:", consonantCount);
