let num = parseInt(prompt("Enter a number: "));
let sum = 0;

do {
    sum += num % 10;
    num = Math.floor(num / 10);
} while (num > 0);

console.log("Sum of digits:", sum);
