let systemGeneratedNumber = Math.floor(Math.random() * 10) + 1;
let userNumber;

do {
    userNumber = parseInt(prompt("Guess the number: "));
    console.log(userNumber);

    if (userNumber < systemGeneratedNumber) {
        console.log("Too low! Try again.");
    } else if (userNumber > systemGeneratedNumber) {
        console.log("Too high! Try again.");
    }
} while (userNumber !== systemGeneratedNumber);

console.log("Correct! You guessed the number.");
