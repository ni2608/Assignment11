let n = parseInt(prompt("How many numbers? "));
let sum = 0;

for (let i = 1; i <= n; i++) {
    let num = parseInt(prompt(`Enter number ${i}: `));
    sum += num;
}

let average = sum / n;
console.log("Sum:", sum);
console.log("Average:", average);
