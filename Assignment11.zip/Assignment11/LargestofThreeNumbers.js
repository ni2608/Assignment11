let num1 = parseInt(prompt("Enter first number: "));
let num2 = parseInt(prompt("Enter second number: "));
let num3 = parseInt(prompt("Enter third number: "));

let largest = Math.max(num1, num2, num3);
console.log(`The largest number is ${largest}.`);
