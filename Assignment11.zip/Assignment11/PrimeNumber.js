let num = parseInt(prompt("Enter a number: "));
let isPrime = true;

for (let i = 2; i <= Math.sqrt(num); i++) {
    if (num % i === 0) {
        isPrime = false;
        break;
    }
}

console.log(isPrime ? `${num} is a prime number.` : `${num} is not a prime number.`);
