let num = parseInt(prompt("Enter a number: "));
let factorial = 1;

while (num > 1) {
    factorial *= num;
    num--;
}

console.log(`Factorial: ${factorial}`);
