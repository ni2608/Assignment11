let num = parseInt(prompt("Enter a number: "));
let numStr = num.toString();
let sum = 0;

for (let digit of numStr) {
    sum += Math.pow(parseInt(digit), numStr.length);
}

console.log(sum === num ? `${num} is an Armstrong number.` : `${num} is not an Armstrong number.`);
