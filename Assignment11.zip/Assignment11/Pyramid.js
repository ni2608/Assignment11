for (let i = 1; i <= 5; i++) {
    let numStr = "";
    for (let j = 1; j <= i; j++) {
        numStr += j;
    }
    for (let j = i - 1; j >= 1; j--) {
        numStr += j;
    }
    console.log(numStr);
}
